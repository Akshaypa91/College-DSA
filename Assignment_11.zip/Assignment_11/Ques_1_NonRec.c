// Non-Recursive Traversals
#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>
#include <string.h>

// Node for expression tree
typedef struct Node {
	char data;
	struct Node* left;
	struct Node* right;
} Node;

// Stack for constructing expression tree
typedef struct Stack {
	Node* node;
	struct Stack* next;
} Stack;

// NodeStack for non-recursive traversal
typedef struct NodeStack {
	Node* node;
	struct NodeStack* next;
} NodeStack;

// Expression Tree Construction
Node* newNode(char data) {
	Node* temp = (Node*)malloc(sizeof(Node));
	temp->data = data;
	temp->left = temp->right = NULL;
	return temp;
}

void push(Stack** top, Node* node) {
	Stack* temp = (Stack*)malloc(sizeof(Stack));
	temp->node = node;
	temp->next = *top;
	*top = temp;
}

Node* pop(Stack** top) {
	if (*top == NULL) return NULL;
	Stack* temp = *top;
	Node* node = temp->node;
	*top = (*top)->next;
	free(temp);
	return node;
}

int isOperator(char c) {
	return (c == '+' || c == '-' || c == '*' || c == '/');
}

Node* constructTree(char* postfix) {
	Stack* stack = NULL;
	for (int i = 0; postfix[i] != '\0'; i++) {
		char c = postfix[i];
		if (isspace(c)) continue; // skip spaces
		Node* node = newNode(c);
		if (isOperator(c)) {
			node->right = pop(&stack);
			node->left = pop(&stack);
		}
		push(&stack, node);
	}
	return pop(&stack);
}

void pushNode(NodeStack** top, Node* node) {
	NodeStack* temp = (NodeStack*)malloc(sizeof(NodeStack));
	temp->node = node;
	temp->next = *top;
	*top = temp;
}

Node* popNode(NodeStack** top) {
	if (!*top) return NULL;
	NodeStack* temp = *top;
	Node* node = temp->node;
	*top = (*top)->next;
	free(temp);
	return node;
}

int isEmpty(NodeStack* top) {
	return top == NULL;
}

void inorderNonRec(Node* root) {
	NodeStack* stack = NULL;
	Node* curr = root;
	while (curr != NULL || !isEmpty(stack)) {
		while (curr != NULL) {
			pushNode(&stack, curr);
			curr = curr->left;
		}
		curr = popNode(&stack);
		printf("%c ", curr->data);
		curr = curr->right;
	}
}

void preorderNonRec(Node* root) {
	if (!root) return;
	NodeStack* stack = NULL;
	pushNode(&stack, root);
	while (!isEmpty(stack)) {
		Node* node = popNode(&stack);
		printf("%c ", node->data);
		if (node->right) pushNode(&stack, node->right);
		if (node->left) pushNode(&stack, node->left);
	}
}

void postorderNonRec(Node* root) {
	if (!root) return;
	NodeStack* stack1 = NULL;
	NodeStack* stack2 = NULL;
	pushNode(&stack1, root);
	while (!isEmpty(stack1)) {
		Node* node = popNode(&stack1);
		pushNode(&stack2, node);
		if (node->left) pushNode(&stack1, node->left);
		if (node->right) pushNode(&stack1, node->right);
	}
	while (!isEmpty(stack2)) {
		Node* node = popNode(&stack2);
		printf("%c ", node->data);
	}
}

int main() {
	char postfix[100];
	printf("Enter postfix expression: ");
	scanf(" %[^\n]", postfix);  // note the space before % to skip leftover newline

	Node* root = constructTree(postfix);

	printf("\nNon-Recursive Traversals:\n");
	printf("Inorder: "); inorderNonRec(root); printf("\n");
	printf("Preorder: "); preorderNonRec(root); printf("\n");
	printf("Postorder: "); postorderNonRec(root); printf("\n");

	return 0;
}